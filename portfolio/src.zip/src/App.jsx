
import { useEffect, useState } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import useSmoothScroll, {
  unlockScroll,
} from "./hooks/useSmoothScroll";
import Intro from "./components/sections/Intro";
import StackStrip from "./components/sections/StackStrip";
import WhatIDo from "./components/sections/WhatIDo";
import Projects from "./components/sections/Projects";
import About from "./components/sections/About";
import Education from "./components/sections/Education";
import ToolsStrip from "./components/sections/ToolsStrip";
import Experience from "./components/sections/Experience";
import Contact from "./components/sections/Contact";
import SectionShell from "./components/sections/SectionShell";
import SiteFooter from "./components/sections/SiteFooter";
import CursorSwarm from "./components/cursors/CursorSwarm";
import { content } from "./data/content";
import { handoff } from "./engine/handoff";

gsap.registerPlugin(ScrollTrigger);

export default function App() {
  useSmoothScroll();

  const [run, setRun] = useState(0);

  useEffect(() => {
    if (run === 0) return;
    window.scrollTo(0, 0);
    unlockScroll();
    const timer = window.setTimeout(() => ScrollTrigger.refresh(), 150);
    return () => window.clearTimeout(timer);
  }, [run]);

  const restart = () => {
    handoff.reset();
    setRun((r) => r + 1);
  };

  const rest = content.sections.filter(
    (s) =>
      ![
        "what-i-do",
        "projects",
        "about",
        "education",
        "experience",
        "contact",
      ].includes(s.id)
  );

  return (
    <>
      <main key={run}>
        <Intro />
        <StackStrip />
        <WhatIDo />
        <Projects />
        <About />
        <Education />
        <ToolsStrip />
        <Experience />
        <Contact />

        {rest.map((s) => (
          <SectionShell key={s.id} {...s} />
        ))}
      </main>

      <SiteFooter key={run} onRestart={restart} />

      <CursorSwarm key={run} />
    </>
  );
}
